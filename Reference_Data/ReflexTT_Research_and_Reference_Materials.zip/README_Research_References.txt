REFLEXTT – RESEARCH AND REFERENCE MATERIALS

This folder contains a Word guide with component datasheet links and table-tennis reaction-time research references.

IMPORTANT SOURCE LIMITATIONS
- The exact model numbers for the LDRs, laser module, servo, OLED, buck converter and RS-775 motors have not all been confirmed.
- Some entries are example references only. Match the model printed on the actual component before treating a datasheet as authoritative.
- The MDD3A datasheet specifies 3 A continuous and 5 A peak (<5 seconds). Verify the exact motor stall current and driver suitability with a knowledgeable supervisor before powering motors.

Included:
- ReflexTT_Research_and_Reference_Guide.docx

The guide includes:
- ESP32-WROOM-32 official datasheet
- Cytron MDD3A motor-driver datasheet
- SSD1306 OLED controller datasheet (if that is the display controller)
- SG90 servo reference (if that is the servo model)
- GL5528 LDR example reference (not confirmed as the team's exact LDR)
- RS-775 motor family manufacturer reference
- Two table-tennis reaction-time / training research papers
