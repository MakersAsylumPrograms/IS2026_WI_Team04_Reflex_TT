REFLEXTT – CIRCUIT DIAGRAMS AND PINOUT REFERENCES

This folder contains the six circuit/wiring reference images supplied for the ReflexTT project.

01_Eight_LDR_Sensor_Circuit.png
Eight LDR sensors, 10 kΩ resistors and ESP32 connections.

02_ESP32_OLED_Servo_5V_Circuit.png
ESP32, OLED display, servo and separate 5 V supply arrangement.

03_Four_Motors_Two_Motor_Drivers.png
Four motors and two motor-driver connection diagram.

04_Four_Buttons_and_OLED.png
Four push buttons and OLED display connections to the ESP32.

05_Servo_and_Buck_Converter.png
Servo and adjustable buck-converter power arrangement.

06_ESP32_12V_Power_and_Buck_Converter.png
ESP32 power connection using a 12 V input and adjustable buck converter.

NOTE:
These are the diagrams supplied by the team. Add separate ESP32 pinout images or pin-assignment tables if available.
Verify the actual component labels, voltages, current ratings, GPIO assignments and wiring before powering the prototype.
